#!/bin/bash
echo "Starting server log and query simulator"
java -jar logMonitor.jar $1
