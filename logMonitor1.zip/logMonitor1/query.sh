#!/bin/bash
echo "Starting monitor query simulator"
java -jar monitorQuery.jar $1
