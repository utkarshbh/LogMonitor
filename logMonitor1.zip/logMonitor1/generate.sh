#!/bin/bash
echo "Starting server log generator"
java -jar logGenerator.jar $1
